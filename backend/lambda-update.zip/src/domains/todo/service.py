"""
Todo service
"""


async def create_daily_tasks_for_routine(routine_id: str, task_date: str):
    """
    Create daily tasks from routine
    TODO: Implement
    """
    pass


async def complete_task(task_id: str, user_id: str) -> dict:
    """
    Mark task as completed and update user stats
    TODO: Implement
    """
    pass
