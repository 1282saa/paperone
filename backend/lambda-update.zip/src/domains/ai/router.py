"""
AI domain router - AI 문제 생성 및 튜터
"""
from fastapi import APIRouter

router = APIRouter()


@router.post("/generate-question")
async def generate_question():
    """AI 문제 생성 - AWS Bedrock"""
    return {"message": "AI 문제 생성 - Bedrock 연동 예정"}


@router.get("/questions")
async def list_generated_questions():
    """생성된 문제 목록"""
    return {"message": "생성된 문제 목록 - 구현 예정"}


@router.post("/tutor")
async def ai_tutor_chat():
    """AI 튜터 복습이 - AWS Bedrock"""
    return {"message": "AI 튜터 - Bedrock 연동 예정"}


@router.get("/tutor/conversations")
async def list_conversations():
    """대화 기록 조회"""
    return {"message": "대화 기록 - 구현 예정"}
