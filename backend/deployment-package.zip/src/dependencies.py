"""
Common dependencies for dependency injection
"""
from typing import Annotated, Optional

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from .core.security import decode_access_token

security = HTTPBearer(auto_error=False)  # auto_error=False로 설정하여 토큰 없이도 허용


# 임시 사용자 모델 (DynamoDB 전환 후)
class MockUser(BaseModel):
    id: str
    email: str = "test@example.com"
    username: str = "test_user"


async def get_current_user(
    credentials: Annotated[Optional[HTTPAuthorizationCredentials], Depends(security)] = None,
) -> MockUser:
    """Get current authenticated user - 임시로 고정 user_id 반환"""
    # 인증이 없으면 테스트용 고정 user_id 사용
    if credentials is None:
        return MockUser(id="test-user-001")

    # 인증 토큰이 있으면 파싱 시도
    try:
        token = credentials.credentials
        payload = decode_access_token(token)
        user_id: str | None = payload.get("sub")
        if user_id:
            return MockUser(id=user_id)
    except Exception:
        pass

    # 실패하면 기본 user_id 반환
    return MockUser(id="test-user-001")


# Type alias for dependency injection
CurrentUser = Annotated[MockUser, Depends(get_current_user)]
