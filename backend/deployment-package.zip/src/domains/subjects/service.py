"""
Subject domain service - 과목 및 문서 비즈니스 로직 (DynamoDB)
"""
from typing import List

from fastapi import HTTPException, status

from .models import Document, Subject
from .repository import DocumentRepository, SubjectRepository
from .schemas import DocumentCreate, DocumentUpdate, SubjectCreate, SubjectUpdate


class SubjectService:
    """과목 서비스"""
    
    def __init__(self):
        self.repo = SubjectRepository()
        self.doc_repo = DocumentRepository()
    
    def create_subject(self, user_id: str, subject_data: SubjectCreate) -> Subject:
        """과목 생성"""
        # 중복 체크
        if self.repo.check_duplicate_name(user_id, subject_data.name):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="이미 존재하는 과목명입니다."
            )
        
        # 새 과목 생성
        subject = Subject(
            user_id=user_id,
            name=subject_data.name,
            color=subject_data.color,
            description=subject_data.description
        )
        
        return self.repo.create(subject)
    
    def get_user_subjects(self, user_id: str) -> List[Subject]:
        """사용자의 모든 과목 조회"""
        return self.repo.get_by_user(user_id)
    
    def get_subject_by_id(self, user_id: str, subject_id: str) -> Subject:
        """특정 과목 조회"""
        subject = self.repo.get_by_id(user_id, subject_id)
        
        if not subject:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="과목을 찾을 수 없습니다."
            )
        
        return subject
    
    def update_subject(self, user_id: str, subject_id: str, subject_data: SubjectUpdate) -> Subject:
        """과목 정보 수정"""
        subject = self.get_subject_by_id(user_id, subject_id)
        
        # 이름 중복 체크 (변경하는 경우)
        if subject_data.name and subject_data.name != subject.name:
            if self.repo.check_duplicate_name(user_id, subject_data.name, exclude_id=subject_id):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="이미 존재하는 과목명입니다."
                )
        
        # 수정
        update_data = subject_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(subject, key, value)
        
        return self.repo.update(subject)
    
    def delete_subject(self, user_id: str, subject_id: str) -> None:
        """과목 삭제 (관련 문서도 모두 삭제)"""
        subject = self.get_subject_by_id(user_id, subject_id)
        
        # 관련 문서 모두 삭제
        documents = self.doc_repo.get_by_subject(subject_id)
        for doc in documents:
            self.doc_repo.delete(subject_id, doc.document_id)
        
        # 과목 삭제
        self.repo.delete(user_id, subject_id)
    
    def update_subject_statistics(self, subject_id: str, user_id: str) -> None:
        """과목 통계 업데이트 (문서 수, 총 페이지 수)"""
        subject = self.get_subject_by_id(user_id, subject_id)
        
        # 통계 계산
        doc_count = self.doc_repo.count_by_subject(subject_id)
        total_pages = self.doc_repo.sum_pages_by_subject(subject_id)
        
        # 업데이트
        subject.total_documents = doc_count
        subject.total_pages = total_pages
        
        self.repo.update(subject)


class DocumentService:
    """문서 서비스"""
    
    def __init__(self):
        self.repo = DocumentRepository()
        self.subject_service = SubjectService()
    
    def create_document(self, user_id: str, document_data: DocumentCreate) -> Document:
        """문서 생성"""
        # 과목 존재 확인
        subject = self.subject_service.get_subject_by_id(user_id, document_data.subject_id)
        
        # 새 문서 생성
        document = Document(
            user_id=user_id,
            subject_id=document_data.subject_id,
            title=document_data.title,
            extracted_text=document_data.extracted_text,
            original_filename=document_data.original_filename,
            image_url=document_data.image_url,
            thumbnail_url=document_data.thumbnail_url,
            pages=document_data.pages,
            file_size=document_data.file_size
        )
        
        result = self.repo.create(document)
        
        # 과목 통계 업데이트
        self.subject_service.update_subject_statistics(document_data.subject_id, user_id)
        
        return result
    
    def get_subject_documents(self, user_id: str, subject_id: str) -> List[Document]:
        """특정 과목의 모든 문서 조회"""
        # 과목 존재 확인
        self.subject_service.get_subject_by_id(user_id, subject_id)
        
        return self.repo.get_by_subject(subject_id)
    
    def get_document_by_id(self, user_id: str, document_id: str, subject_id: str = None) -> Document:
        """특정 문서 조회"""
        if not subject_id:
            # user_id로 검색하여 subject_id 찾기
            user_docs = self.repo.get_by_user(user_id)
            document = next((doc for doc in user_docs if doc.document_id == document_id), None)
        else:
            document = self.repo.get_by_id(subject_id, document_id)
        
        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="문서를 찾을 수 없습니다."
            )
        
        # 사용자 권한 확인
        if document.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="접근 권한이 없습니다."
            )
        
        return document
    
    def update_document(self, user_id: str, document_id: str, document_data: DocumentUpdate) -> Document:
        """문서 정보 수정"""
        # 먼저 user_id로 문서 찾기
        document = self.get_document_by_id(user_id, document_id)
        
        # 수정
        update_data = document_data.model_dump(exclude_unset=True)
        old_pages = document.pages
        
        for key, value in update_data.items():
            setattr(document, key, value)
        
        result = self.repo.update(document)
        
        # 페이지 수 변경 시 과목 통계 업데이트
        if 'pages' in update_data and old_pages != document.pages:
            self.subject_service.update_subject_statistics(document.subject_id, user_id)
        
        return result
    
    def delete_document(self, user_id: str, document_id: str) -> None:
        """문서 삭제"""
        document = self.get_document_by_id(user_id, document_id)

        subject_id = document.subject_id

        self.repo.delete(subject_id, document_id)

        # 과목 통계 업데이트
        self.subject_service.update_subject_statistics(subject_id, user_id)

    def toggle_review_status(self, user_id: str, document_id: str) -> Document:
        """문서 복습 완료 상태 토글"""
        document = self.get_document_by_id(user_id, document_id)

        # 복습 완료 상태 토글
        document.review_completed = not document.review_completed

        # 복습 완료 시 last_reviewed_at 업데이트
        if document.review_completed:
            from datetime import datetime
            document.last_reviewed_at = datetime.utcnow().isoformat()
            document.review_count += 1

        return self.repo.update(document)
