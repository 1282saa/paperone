"""
Subjects domain router - 과목 및 문서 API (DynamoDB)
"""
from typing import List

from fastapi import APIRouter, Depends, status

from ...dependencies import CurrentUser
from .schemas import (
    DocumentCreate,
    DocumentResponse,
    DocumentUpdate,
    SubjectCreate,
    SubjectResponse,
    SubjectUpdate,
)
from .service import DocumentService, SubjectService

router = APIRouter()


# Subject Endpoints

@router.post("", response_model=SubjectResponse, status_code=status.HTTP_201_CREATED)
async def create_subject(
    subject_data: SubjectCreate,
    current_user: CurrentUser,
):
    """과목 생성"""
    service = SubjectService()
    subject = service.create_subject(current_user.id, subject_data)
    return subject


@router.get("", response_model=List[SubjectResponse])
async def get_my_subjects(
    current_user: CurrentUser,
):
    """내 과목 목록 조회"""
    service = SubjectService()
    subjects = service.get_user_subjects(current_user.id)
    return subjects


@router.get("/{subject_id}", response_model=SubjectResponse)
async def get_subject_detail(
    subject_id: str,
    current_user: CurrentUser,
):
    """과목 상세 조회"""
    service = SubjectService()
    subject = service.get_subject_by_id(current_user.id, subject_id)
    return subject


@router.patch("/{subject_id}", response_model=SubjectResponse)
async def update_subject(
    subject_id: str,
    subject_data: SubjectUpdate,
    current_user: CurrentUser,
):
    """과목 정보 수정"""
    service = SubjectService()
    subject = service.update_subject(current_user.id, subject_id, subject_data)
    return subject


@router.delete("/{subject_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_subject(
    subject_id: str,
    current_user: CurrentUser,
):
    """과목 삭제"""
    service = SubjectService()
    service.delete_subject(current_user.id, subject_id)


# Document Endpoints

@router.post("/documents", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def create_document(
    document_data: DocumentCreate,
    current_user: CurrentUser,
):
    """문서 생성"""
    service = DocumentService()
    document = service.create_document(current_user.id, document_data)
    return document


@router.get("/{subject_id}/documents", response_model=List[DocumentResponse])
async def get_subject_documents(
    subject_id: str,
    current_user: CurrentUser,
):
    """특정 과목의 문서 목록 조회"""
    service = DocumentService()
    documents = service.get_subject_documents(current_user.id, subject_id)
    return documents


@router.get("/documents/{document_id}", response_model=DocumentResponse)
async def get_document_detail(
    document_id: str,
    current_user: CurrentUser,
):
    """문서 상세 조회"""
    service = DocumentService()
    document = service.get_document_by_id(current_user.id, document_id)
    return document


@router.patch("/documents/{document_id}", response_model=DocumentResponse)
async def update_document(
    document_id: str,
    document_data: DocumentUpdate,
    current_user: CurrentUser,
):
    """문서 정보 수정"""
    service = DocumentService()
    document = service.update_document(current_user.id, document_id, document_data)
    return document


@router.delete("/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(
    document_id: str,
    current_user: CurrentUser,
):
    """문서 삭제"""
    service = DocumentService()
    service.delete_document(current_user.id, document_id)


@router.patch("/documents/{document_id}/review", response_model=DocumentResponse)
async def toggle_review_status(
    document_id: str,
    current_user: CurrentUser,
):
    """문서 복습 완료 상태 토글"""
    service = DocumentService()
    document = service.toggle_review_status(current_user.id, document_id)
    return document
