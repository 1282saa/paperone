"""
Subjects domain - 과목 관리
"""
