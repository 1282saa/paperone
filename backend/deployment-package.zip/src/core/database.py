"""
Database configuration - DynamoDB 사용으로 인해 SQLAlchemy 제거
"""
# DynamoDB를 사용하므로 SQLAlchemy는 필요 없음
# 기존 코드 호환성을 위해 빈 모듈로 유지


class Base:
    """기존 코드 호환성을 위한 더미 Base 클래스"""
    pass


async def get_db():
    """
    DynamoDB를 사용하므로 실제 세션은 없음
    기존 코드 호환성을 위한 더미 함수
    """
    yield None
