# Version here is used for the package version via the `[tool.hatch.version]` section of `pyproject.toml`.
VERSION = '0.25.0'
